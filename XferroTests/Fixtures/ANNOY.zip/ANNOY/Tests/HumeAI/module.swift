//
//  module.swift
//  AI
//
//  Created by Jared Davidson on 11/22/24.
//

import HumeAI

let HUMEAI_API_KEY = ""

var client = HumeAI.Client(
    apiKey: HUMEAI_API_KEY
)
