//
//  HumeAI.swift
//  AI
//
//  Created by Jared Davidson on 11/22/24.
//

import Swift

public enum HumeAI {
    
}
