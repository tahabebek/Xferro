//
// Copyright (c) Vatsal Manot
//

import Foundation
import Swallow

public enum AbstractLLM {
    
}
