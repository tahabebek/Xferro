//
//  Rime.swift
//  AI
//
//  Created by Jared Davidson on 11/21/24.
//

import Swift

public enum Rime {
    
}
