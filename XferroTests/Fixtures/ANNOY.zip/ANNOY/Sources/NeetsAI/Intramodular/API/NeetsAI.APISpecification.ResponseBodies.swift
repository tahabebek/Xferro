//
//  NeetsAI.APISpecification.ResponseBodies.swift
//  AI
//
//  Created by Jared Davidson on 11/22/24.
//

import Foundation

extension NeetsAI.APISpecification {
    enum ResponseBodies {
        typealias ChatCompletion = NeetsAI.ChatCompletion
    }
}
