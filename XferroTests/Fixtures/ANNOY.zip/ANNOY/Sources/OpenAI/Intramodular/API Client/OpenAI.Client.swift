//
// Copyright (c) Vatsal Manot
//

import CoreMI
import CorePersistence
import LargeLanguageModels
import NetworkKit
import Swift

public final class _OpenAI_Client: HTTPClient, _StaticSwift.Namespace {
    public typealias APISpecification = OpenAI.APISpecification
    
    public let interface: OpenAI.APISpecification
    public let session: HTTPSession
    
    @Resource(get: \.listModels, \.data)
    var __cached_models: [OpenAI.ModelObject]?
    
    public init(interface: OpenAI.APISpecification, session: HTTPSession) {
        self.interface = interface
        self.session = session
    }
    
    public convenience init(apiKey: String?) {
        var apiKey: String? = apiKey
        
        if apiKey == nil, ProcessInfo.processInfo._isRunningWithinXCTest {
            #try(.optimistic) {
                apiKey = try _PreternaturalDotFile.key(for: .openAI)
            }
        }
        
        self.init(
            interface: OpenAI.APISpecification(configuration: .init(apiKey: apiKey)),
            session: .shared
        )
    }
    
    public convenience init(
        configuration: OpenAI.APISpecification.Configuration,
        session: HTTPSession = .shared
    ) {
        self.init(
            interface: APISpecification(configuration: configuration),
            session: session
        )
    }
    
    public convenience init(host: URL) {
        self.init(
            configuration: APISpecification.Configuration(host: host),
            session: HTTPSession(host: host)
        ) 
    }
}

extension OpenAI {
    public typealias Client = _OpenAI_Client

    @available(*, deprecated, renamed: "OpenAI.Client")
    public typealias APIClient = _OpenAI_Client
}

extension OpenAI.Client {
    public var models: [OpenAI.ModelObject] {
        get async throws {
            try await run(\.listModels).data // FIXME: Auto-paginate
        }
    }
    
    public func createCompletion(
        model: OpenAI.Model,
        prompt: String,
        parameters: OpenAI.Client.TextCompletionParameters
    ) async throws -> OpenAI.TextCompletion {
        let requestBody = OpenAI.APISpecification.RequestBodies.CreateCompletion(
            prompt: .left(prompt),
            model: model,
            parameters: parameters,
            stream: false
        )
        
        return try await run(\.createCompletions, with: requestBody)
    }
    
    public func createCompletion(
        model: OpenAI.Model,
        prompts: [String],
        parameters: OpenAI.Client.TextCompletionParameters
    ) async throws -> OpenAI.TextCompletion {
        let requestBody = OpenAI.APISpecification.RequestBodies.CreateCompletion(
            prompt: .right(prompts),
            model: model,
            parameters: parameters,
            stream: false
        )
        
        return try await run(\.createCompletions, with: requestBody)
    }
    
    @_disfavoredOverload
    public func createChatCompletion(
        messages: [OpenAI.ChatMessage],
        model: OpenAI.Model,
        parameters: OpenAI.Client.ChatCompletionParameters
    ) async throws -> OpenAI.ChatCompletion {
        let requestBody = OpenAI.APISpecification.RequestBodies.CreateChatCompletion(
            messages: messages,
            model: model,
            parameters: parameters,
            stream: false
        )
        
        return try await run(\.createChatCompletions, with: requestBody)
    }
    
    public func createChatCompletion(
        messages: [OpenAI.ChatMessage],
        model: OpenAI.Model.Chat,
        parameters: OpenAI.Client.ChatCompletionParameters
    ) async throws -> OpenAI.ChatCompletion {
        try await createChatCompletion(
            messages: messages,
            model: .chat(model),
            parameters: parameters
        )
    }
    
    public func createTextOrChatCompletion(
        prompt: String,
        system: String?,
        model: OpenAI.Model,
        temperature: Double?,
        topProbabilityMass: Double?,
        maxTokens: Int?
    ) async throws -> Either<OpenAI.TextCompletion, OpenAI.ChatCompletion> {
        switch model {
            case .chat(let model): do {
                let messages: [OpenAI.ChatMessage] = system.map({ [.system($0), .user(prompt)] }) ?? [.user(prompt)]
                
                let result = try await createChatCompletion(
                    messages: messages,
                    model: model,
                    parameters: .init(temperature: temperature, topProbabilityMass: topProbabilityMass, maxTokens: maxTokens)
                )
                
                return .right(result)
            }
            case .instructGPT: do {
                let result = try await createCompletion(
                    model: model,
                    prompt: prompt,
                    parameters: .init(maxTokens: maxTokens, temperature: temperature, topProbabilityMass: topProbabilityMass)
                )
                
                return .left(result)
            }
            default:
                throw _PlaceholderError()
        }
    }
}

extension OpenAI.Client {
    @discardableResult
    public func createRun(
        threadID: OpenAI.Thread.ID,
        assistantID: String,
        model: OpenAI.Model? = nil,
        instructions: String? = nil,
        tools: [OpenAI.Tool]?,
        metadata: [String: String]? = nil
    ) async throws -> OpenAI.Run {
        let result = try await run(
            \.createRun,
             with: (
                thread: threadID,
                requestBody: .init(
                    assistantID: assistantID,
                    model: model,
                    instructions: instructions,
                    tools: tools,
                    metadata: metadata
                )
             )
        )
        
        return result
    }
    
    public func retrieve(
        run: OpenAI.Run.ID,
        thread: OpenAI.Thread.ID
    ) async throws -> OpenAI.Run {
        try await self.run(\.retrieveRunForThread, with: (thread, run))
    }
}

// MARK: - Conformances

extension OpenAI.Client: _MaybeAsyncProtocol {
    public func _resolveToNonAsync() async throws -> Self {
        self
    }
}

extension OpenAI.Client: PersistentlyRepresentableType {
    public static var persistentTypeRepresentation: some IdentityRepresentation {
        CoreMI._ServiceVendorIdentifier._OpenAI
    }
}

// MARK: - Auxiliary

extension OpenAI.Client {
    public struct TextCompletionParameters: Codable, Hashable {
        public var suffix: String?
        public var maxTokens: Int?
        public var temperature: Double?
        public var topProbabilityMass: Double?
        public var n: Int
        public var logprobs: Int?
        public var stop: Either<String, [String]>?
        public var presencePenalty: Double?
        public var frequencyPenalty: Double?
        public var bestOf: Int?
        public var logitBias: [String: Int]?
        public var user: String?
        
        public init(
            suffix: String? = nil,
            maxTokens: Int? = 16,
            temperature: Double? = 1,
            topProbabilityMass: Double? = 1,
            n: Int = 1,
            logprobs: Int? = nil,
            echo: Bool? = false,
            stop: Either<String, [String]>? = nil,
            presencePenalty: Double? = 0,
            frequencyPenalty: Double? = 0,
            bestOf: Int? = 1,
            logitBias: [String: Int]? = nil,
            user: String? = nil
        ) {
            self.suffix = suffix
            self.maxTokens = maxTokens
            self.temperature = temperature
            self.topProbabilityMass = topProbabilityMass
            self.n = n
            self.logprobs = logprobs
            self.stop = stop?.nilIfEmpty()
            self.presencePenalty = presencePenalty
            self.frequencyPenalty = frequencyPenalty
            self.bestOf = bestOf
            self.logitBias = logitBias
            self.user = user
        }
    }
}
