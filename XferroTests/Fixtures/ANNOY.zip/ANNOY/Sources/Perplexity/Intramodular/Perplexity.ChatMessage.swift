//
// Copyright (c) Vatsal Manot
//

import Foundation
import OpenAI

extension Perplexity {
    public typealias ChatMessage = OpenAI.ChatMessage
}
